// api/responses.js
const { getDB } = require('./_db');
const { setCors } = require('./_auth');

const VALID_P = ['G', 'R', 'C', 'E'];
const VALID_S = ['bright', 'natural', 'healthy', 'white'];

module.exports = async (req, res) => {
  setCors(req, res);
  if (req.method === 'OPTIONS') return res.status(200).end();
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });

  const { personality, shade, answers = [] } = req.body || {};

  if (!VALID_P.includes(personality) || !VALID_S.includes(shade)) {
    return res.status(400).json({ error: 'Invalid personality or shade' });
  }

  const ip = (req.headers['x-forwarded-for'] || '').split(',')[0].trim() || null;
  const ua = req.headers['user-agent'] || null;

  const db = getDB();
  const { data, error } = await db
    .from('responses')
    .insert({ personality, shade, answers, ip, ua })
    .select('id')
    .single();

  if (error) {
    console.error(error);
    return res.status(500).json({ error: 'DB error' });
  }

  res.status(200).json({ ok: true, id: data.id });
};
